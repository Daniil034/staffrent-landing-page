export const en_title = "KES ME OLEME"
export const en_staffrent = 'STAFFRENT';
export const en_first_paragraph = 'on üks juhtivaid personali allhanke- ja personaliagentuure Balti riikides ja Lääne-Euroopas, mis on alates 2013. aastast spetsialiseerunud kesk- ja juhtivtöötajate palkamisele erinevates erialades ja majandussektorites. Tootliku töö aastate jooksul oleme aidanud enam kui 600 ettevõttel oma tööd optimeerida, vähendades personaliosakonna koormust ning minimeerides maksu- ja personalikulusid.';
export const en_second_paragraph = 'Oleme võrdselt tähelepanelikud oma klientide personalivajaduste ja kandidaatide karjääri kasvu suhtes. Tänu individuaalsele lähenemisele ja sügavatele erialastele teadmistele loovad meie konsultandid pikaajalisi vastastikku kasulikke suhteid klientide ja kandidaatidega. Tegutseme edukalt kõigis majandussektorites, millele oleme spetsialiseerunud, samuti kõigis kohaloleku piirkondades.';
export const en_third_paragraph = 'Me ei täida ainult vabu töökohti, vaid kohandame teie vajadustele vastavaid kohandatud lahendusi, alates kõrgelt kvalifitseeritud värbamisest kuni kõrgelt spetsialiseeritud tööturu aruanneteni.'
export const en_second_title = 'kliendid saavad võimaluse:';
export const en_first_opportunity = 'Täitke viivitamatult personali puudus motiveeritud töötajatega nõutavas koguses nõutud aja jooksul - ilma ajutiste töötajate registreerimiseta, nende kvalifikatsiooni kontrollimata, ilma tagatud sotsiaaltoetuste lisakuludeta.';
export const en_second_opportunity = 'Vähendage kiiresti ettevõtte täistööajaga töötajate arvu, sõltuvalt hooajalistest turumuutustest töömahus. Liinitöötajate käibe probleemidest vabanemine personaliosakonna mahalaadimisega.';

export const third_opportunity = 'Vähendage palgaarvestuse kohustusi';
export const en_fourth_paragraph = 'Praeguses majanduslikus olukorras on allhankeettevõttest töötajate meelitamine tõhus viis ettevõtete personali lahendamiseks.Partnerlus agentuuriga STAFFRENT välistab madala kvaliteediga personali pakkumise riskid, võimaldades organisatsioonil vabalt areneda, kulutamata raha teisestele tööprotsessidele.';
