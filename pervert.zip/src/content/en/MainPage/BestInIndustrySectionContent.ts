export const en_title = "TÖÖSTUSE PARIM";
export const first_paragraph_title = " «STAFFRENT» erineb teistest agentuuridest oma laia teenustevaliku poolest nii tööandjatele kui ka tööotsijatele. Vabade töökohtade kiire ja kvaliteetne sulgemine, mis tuleneb:";
export const first_paragraph_dues = [
    "moodustatud ekspertide meeskond",
    "kogemus arvukate värbamisprojektide elluviimisel",
    "Patenteeritud autori valiku- ja hindamismeetodid",
    "suur andmebaas asjakohastest spetsialistidest",
    "võtmed kätte lahenduste pakkumine mõlemale poolele"
];

export const second_paragraph = "Meie värbajad kasutavad edukalt personaliotsingu täiustatud meetodeid, kandidaatide valimist vastavalt kliendiprojekti nõuetele, nende professionaalsete ja isiklike parameetrite hindamist. Operatiivselt leiame ja pakume töötajatele kõrget sisemist motivatsiooni, mis mõjutab ka töötaja töö kvaliteeti ja kestust Teie projekti raames."
export const third_paragraph = "Usaldades töötajate otsimise allhankeagentuuri spetsialistidele, saate juurdepääsu meie ulatuslikule kandidaatide andmebaasile. Kui vajate kitsa profiiliga spetsialiste ja ainulaadse töökogemusega spetsialiste, viivad STAFFRENT värbajad läbi asjakohased turu-uuringud ja esitavad viivitamatult kandidaatide nimekirjad, kasutades otsese personaliotsingu ja sihtotsingu meetodeid."
