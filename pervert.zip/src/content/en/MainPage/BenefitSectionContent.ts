export const en_title = "Kuidas saate kasu personali allhankest?";
export const en_first_cloud = "Personali allhange võimaldab palgata vajalikku personali ajutiseks või alaliseks tööks, viies äriprotsessi üle meie teenustesse.";
export const en_second_cloud = "Allhange võimaldab teil saavutada paremaid tulemusi, ilma et oleks vaja oma värbamisosakonda.";
export const en_third_cloud = "Valime ja koolitame töötajad lühikese aja jooksul, et nad saaksid täita konkreetseid ülesandeid, mille olete neile seadnud.";
export const en_fourth_cloud = "Me kanname vastutust oma töötajate ja teie äriülesannete täitmise eest.";
export const en_fifth_cloud = "Puuduvad kohustused seoses töösuhetega töötajatega.";
