export const en_title = "Peamised tegevusvaldkonnad";
