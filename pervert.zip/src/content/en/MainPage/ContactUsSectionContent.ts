export const en_title = "S Võta meiega ühendust";
export const en_company_name = "STAFFRENT UAB / STAFFRENT SIA";
export const en_address = "Oude Trambaan 50, 2265 DA Leidschendamis";
export const en_email = "info@staffrent.ee / offer@staffrent.nl";
export const en_phone_number = "+372 57856099 / + 31 97 010265013";
