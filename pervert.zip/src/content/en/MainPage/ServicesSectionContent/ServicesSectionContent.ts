export const en_title = "VÄRBAMIS- JA ALLHANKETEENUSED KOGU EUROOPAS";
export const en_description_first = "Aitame teil saavutada oma ettevõtte eesmärke.";
export const en_description_second = "Kulude vähendamine teeb teile muret?";
export const en_description_third = "Garanteeritud tulemus võimalikult lühikese aja jooksul!";
