import {VacancyItemProps} from "./VacancyItem/VacancyItem";
import locksmithImg from 'shared/images/locksmithImage.png'
import technicianImg from 'shared/images/technicianImage.png'
import solarTechnicianImg from 'shared/images/solarTechnicianImage.png'

export const VACANCY_LIST: VacancyItemProps[] = [
    {
        title: 'A Paigaldaja - Tootmislao püstitaja',
        imageSrc: locksmithImg,
        imagePosition: 'right',
        imageMarginRight: -6,
        imageMarginLeft: -6,
        bulletPoints: [
            {
                bulletPointTitle: 'Kohustused:',
                bulletPointBody: <>
                    - Metallkonstruktsioonide valmistamise ja paigaldamise lukksepatööde teostamine;<br/>
                    - Töö tegemine käsitööriistadega;<br/>
                    - materjali ettevalmistamine (metalli lõikamine ja puhastamine);<br/>
                    - metalltoodete (leht, toru, traat) kokkupanek;<br/>
                    - metallkonstruktsioonide kokkupanek;<br/>
                    - Keevitustööd.
                </>
            },
            {
                bulletPointTitle: 'Nõuded:',
                bulletPointBody: <>
                    - Vähemalt 3-aastane kogemus lukksepatöös;<br/>
                    - jooniste lugemine;<br/>
                    - Oskused ja kogemused elektritööriistadega;<br/>
                    - keskharidusega tehniline haridus - soovitav;<br/>
                    - Kogemus tootmiskeskkonnas - soovitav;<br/>
                    - Ausus, distsipliin, töökus.
                </>
            },
            {
                bulletPointTitle: 'Tingimused:',
                bulletPointBody: <>
                    - ametlik registreerimine;<br/>
                    - Olemas on tööriided ja käsitööriistad;<br/>
                    - Igapäevane töögraafik (5/2);<br/>
                    - stabiilne palk ja ettemaksete võimalus;<br/>
                    - Head töötingimused ja kuraatori pidev toetus;<br/>
                    - Pakutakse majutust ja transporti;<br/>
                    - Abi kõigi dokumentide ettevalmistamisel.
                </>
            }
        ]
    },
    {
        title: 'Ökonik/Hüdraulika spetsialist',
        imageSrc: technicianImg,
        imagePosition: 'left',
        imageMarginLeft: -7,
        imageMarginRight: -6,
        bulletPoints: [
            {
                bulletPointTitle: 'Töö kirjeldus:',
                bulletPointBody: <>
                    - hüdraulikaseadmete ja -seadmete remont ja hooldus<br/>
                    - Hüdraulilise torustiku paigaldus<br/>
                    - Hüdraulikavoolikute valmistamine<br/>
                    - hüdrosilindrite remont<br/>
                    - hüdrauliliste lahenduste loomine ja rakendamine
                </>
            },
            {
                bulletPointTitle: 'Ootused kandidaadile:',
                bulletPointBody: <>
                    - eelnev kokkupuude tehniliste hooldus- ja remonditöödega<br/>
                    - vähemalt B-kategooria juhiluba<br/>
                    - täpsus ja kohusetunne<br/>
                    - tahe õppida ja ennast täiendada<br/>
                    - Inglise keele oskus<br/>
                    - kasulikud on teadmised ja oskused hüdraulika, mehaanika ja elektri valdkonnas
                </>
            },
            {
                bulletPointTitle: 'Tingimused:',
                bulletPointBody: <>
                    - ametlik registreerimine;<br/>
                    - Olemas on tööriided ja käsitööriistad;<br/>
                    - Igapäevane töögraafik (5/2);<br/>
                    - stabiilne palk ja ettemaksete võimalus;<br/>
                    - Head töötingimused ja kuraatori pidev toetus;<br/>
                    - Pakutakse majutust ja transporti;<br/>
                    - Abi kõigi dokumentide koostamisel.
                </>
            }
        ]
    },
    {
        title: 'Päikesepaneelide tehnik',
        imageSrc: solarTechnicianImg,
        imageMarginRight: -8,
        imageMarginLeft: -6,
        imagePosition: 'right',
        bulletPoints: [
            {
                bulletPointTitle: '',
                bulletPointBody: `
                    Inspekteerimistehnik vastutab installitud projektide kõigi vajalike kontrollide ajastamise, läbiviimise ja salvestamise eest. Te kõnnite koos määratud inspektoritega läbi, tagades, et päikesesüsteem on õigesti paigaldatud ja kooskõlas kõigi eeskirjadega! See ametikoht nõuab heakskiidu saamiseks ka väikeste remonditööde tegemist!
                `
            },
            {
                bulletPointTitle: 'Töö kirjeldus:',
                bulletPointBody: <>
                    - Teostage plaanipäraselt päikese-, elektri- või ehitusülevaatusi<br/>
                    - Koordineerida kontrolle klientide ja jurisdiktsioonidega<br/>
                    - Korrastatud ja tõhusa kalendri pidamine<br/>
                    - Looge positiivne ja püsiv kliendikogemus, arutades projekti ajakavasid pärast ülevaatuse
                    allkirjastamist, täpsustades ja edastades muresid sisemiselt<br/>
                    - Kasutage tarkvarasüsteeme projektipõhiste tulemuste ja ülesannete salvestamiseks, haldamiseks ja
                    värskendamiseks<br/>
                    - Potentsiaalselt on vaja täita väiksemaid ülesandeid, nagu kanali värvimine, NEC kleebiste /
                    plakatite rakendamine jne,
                    etc.
                </>
            },
            {
                bulletPointTitle: 'Ootused kandidaadile:',
                bulletPointBody: <>
                    - Eelistatud on päikesepaigaldis või päikeseelektri kogemus<br/>
                    - Isik, kellel on kehtiv juhiluba ja kes peab puhast sõiduarvestust<br/>
                    - Järgige ettevõtte ohutuseeskirju ja -protseduure<br/>
                    - Peab omama suurepäraseid organiseerimis- ja ajajuhtimisoskusi<br/>
                    - Tugev suhtlemisoskus, et pakkuda erakordset klienditeenindust ning suhelda klientide ja
                    inspektoritega professionaalselt ja viisakalt<br/>
                    - Peab olema mugav töötada kõrgustes<br/>
                    - Elektrikogemus (3+ aastat)
                </>
            }
        ]
    }
]
