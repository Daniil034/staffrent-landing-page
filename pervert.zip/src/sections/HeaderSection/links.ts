export const LINKS: { href: string, label: string }[] = [
    {
        href: '/',
        label: 'Peamine'
    },
    {
        href: '/about',
        label: 'Meie kohta'
    },
    {
        href: '/contact-us',
        label: 'Võta meiega ühendust'
    },
    {
        href: '/employers',
        label: 'Tööandjale'
    },
    {
        href: '/job-seeker',
        label: 'Tööotsija'
    },
    {
        href: '/faq',
        label: 'KKK'
    }
]
