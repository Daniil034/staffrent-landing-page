// @flow
import * as React from 'react';
import {ContactDetailsSection} from "../../sections/ContactDetailsSection/ContactDetailsSection";

type Props = {};

export function ContactUsPage(props: Props) {
    return (
        <div>
            <ContactDetailsSection/>
        </div>
    );
}
