import styles from './JobSeekerPage.module.scss';
import {ListOfVacanciesSection} from "../../sections/ListOfVacanciesSection/ListOfVacanciesSection";

export function JobSeekerPage() {
    return (
        <div>
            <ListOfVacanciesSection/>
        </div>
    );
}
